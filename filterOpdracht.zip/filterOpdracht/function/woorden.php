<?php

class woorden
{
    // Crund systeem
    public function createWoord()
    {

        if (isset($_POST['submit']) && isset($_POST['voegWoordToe']) && isset($_POST['voegNummerToe'])) {

            $woord = $_POST['voegWoordToe'];
            $nummer = $_POST["voegNummerToe"];

            $db = new Database;
            $liqry = $db->con->prepare("INSERT INTO `woorden`(`Woord` , `Gradatie_scheldwoord`) VALUES ('$woord', '$nummer')");
            if ($liqry === false) {
                echo mysqli_error($db->con);
            } else {
                // $liqry->bind_param('s', $name);
                if ($liqry->execute()) {
                    echo "woord is toegevoegd";
                }
            }
            $liqry->close();
        } else {
            echo 'niks is toegevoegd';
        }
    }



    function readWoorden()
    {
        $db = new Database;
        $con = $db->getConnection();
        $readqry = ("SELECT id, woord, Gradatie_scheldwoord, goedgekeurd FROM `woorden`");
        $result = $con->query($readqry);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                echo "scheldwoord:";
                echo "<br>";
                echo "<br>";
                echo $row['id'] . "-" . $row['woord']. "-" . $row['gradatie']. "-" . $row['goedgekeurd'];
            }
        } else {
            echo "0 results";
        }
    }





    private function updateWoord()
    {
    }

    private function deleteWoord()
    {
    }

    // scheldwoorden filter functie






    function filterScheldWoorden()
    {

        // $submit = $_POST["verzend"];

        if (isset($_POST["zin"]) && $_POST["zin"] != "") {
            echo "checken voor scheldwoord...";
            echo "<br>";

        } else {
            echo "vul iets in!";
        }  
    }
}
