<?php
include("core/header.php");
include("core/db_connect.php");
$db = new Database;
?>




<?php
include("core/footer.php")
?>
