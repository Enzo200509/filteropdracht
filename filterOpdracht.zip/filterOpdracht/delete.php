<?php
include("core/header.php");
include("core/db_connect.php");
include("function/woorden.php");
// $db = new Database;

$readWoorden = new woorden;
$readWoordenFunctie = $readWoorden->readWoorden();

include("core/footer.php")
?>